# example:2_B.2.2 
# example:2 : Some important statistical concepts : Statistical theory : A/B tests 
# Title: 
                    Summarizing the A/B test into a contingency table 


                    Summarizing the A/B test into a contingency table
                    tab <- table(d)
print(tab)
     converted
group     0     1
    A 94979  5021
    B  9398   602

