# example 5.13 of section 5.2.5 
# (example 5.13 of section 5.2.5)  : Choosing and evaluating models : Evaluating models : Evaluating clustering models 
# Title: Calculating the size of each cluster 

table(d$cluster)

##  1  2  3  4  5
## 10 27 18 17 28

