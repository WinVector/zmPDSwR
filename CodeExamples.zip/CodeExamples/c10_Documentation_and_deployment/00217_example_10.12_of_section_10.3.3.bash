# example 10.12 of section 10.3.3 
# (example 10.12 of section 10.3.3)  : Documentation and deployment : Using comments and version control for running documentation : Using version control to explore your project 
# Title: Annoying work 

git blame README.md
376f9bce (John Mount   2013-05-15 07:58:14 -0700  1) ## Support ...
376f9bce (John Mount   2013-05-15 07:58:14 -0700  2) # by Nina  ...
2541bb0b (Marius Butuc 2013-04-24 23:52:09 -0400  3)
2541bb0b (Marius Butuc 2013-04-24 23:52:09 -0400  4) Works deri ...
2541bb0b (Marius Butuc 2013-04-24 23:52:09 -0400  5)

