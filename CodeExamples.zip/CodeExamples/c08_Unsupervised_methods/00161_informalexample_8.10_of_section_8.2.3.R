# informalexample 8.10 of section 8.2.3 
# (informalexample 8.10 of section 8.2.3)  : Unsupervised methods : Association rules : Mining association rules with the arules package 

inspect(head((sort(rules, by="confidence")), n=5))

