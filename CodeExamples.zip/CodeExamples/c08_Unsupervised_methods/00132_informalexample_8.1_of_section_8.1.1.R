# informalexample 8.1 of section 8.1.1 
# (informalexample 8.1 of section 8.1.1)  : Unsupervised methods : Cluster analysis : Distances 

edist(x, y) <- sqrt((x[1]-y[1])^2 + (x[2]-y[2])^2 + ...)

