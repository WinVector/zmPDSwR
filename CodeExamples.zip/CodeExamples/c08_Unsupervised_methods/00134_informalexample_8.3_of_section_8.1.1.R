# informalexample 8.3 of section 8.1.1 
# (informalexample 8.3 of section 8.1.1)  : Unsupervised methods : Cluster analysis : Distances 

mdist(x, y) <- sum(abs(x[1]-y[1]) + abs(x[2]-y[2]) + ...)

