# informalexample:1_A.1.5 
# informalexample:1 : Installing tools and working with R : Installing the tools : R resources 
install.packages('ctv')
library('ctv')
install.views('TimeSeries')
