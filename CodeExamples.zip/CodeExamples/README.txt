
Example code and data for "Practical Data Science with R" by Nina Zumel and John Mount, Manning 2014.
The book: "Practical Data Science with R" by Nina Zumel and John Mount, Manning 2014: http://www.manning.com/zumel/
The support site: https://github.com/WinVector/zmPDSwR
This zip file: https://github.com/WinVector/zmPDSwR/blob/master/CodeExamples.zip

Code license: 
  Example code is licensed under a Creative Commons Attribution-NonCommercial 3.0 Unported License. http://creativecommons.org/licenses/by-nc/3.0/
  No guarantee, indemnification or claim of fitness is made regarding any of these items.
  No claim of license on works of others or derived data.
