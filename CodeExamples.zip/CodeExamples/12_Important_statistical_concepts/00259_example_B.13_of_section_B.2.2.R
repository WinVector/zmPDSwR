# example B.13 of section B.2.2 
# (example B.13 of section B.2.2)  : Important statistical concepts : Statistical theory : A/B tests 
# Title:  Summarizing the A/B test into a contingency table 

 Summarizing the A/B test into a contingency table
                    tab <- table(d)
print(tab)
     converted
group     0     1
    A 94979  5021
    B  9398   602

