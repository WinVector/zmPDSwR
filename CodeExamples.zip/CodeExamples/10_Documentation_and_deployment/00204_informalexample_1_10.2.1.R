# informalexample:1_10.2.1 
# informalexample:1 : Documentation and deployment : Using knitr to produce milestone documentation : What is knitr? 


                                        library(knitr)
knit('simple.Rmd')

