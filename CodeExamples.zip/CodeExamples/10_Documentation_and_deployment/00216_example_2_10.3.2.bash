# example:2_10.3.2 
# example:2 : Documentation and deployment : Using comments and version control for running documentation : Using version control to record history 
# Title: 
                                        Checking your project history 


                                        Checking your project history
                                        commit c02839e0b34172f54fd68201f64895295b9d7609
Author: John Mount <jmount@win-vector.com>
Date:   Sat Nov 9 13:28:30 2013 -0800

    add export of random forest model

commit 974a8d5b95bdf25b95d23ef75d08d8aa6c0d74fe
Author: John Mount <jmount@win-vector.com>
Date:   Sat Nov 9 12:01:14 2013 -0800

    Add rook examples

