# example:2_10.3.2 
# example:2 : Documentation and deployment : Using comments and version control for running documentation : Using version control to record history 
# Title: 
                                        Checking your project status 


                                        Checking your project status
                                        $ git status
# On branch master
nothing to commit (working directory clean)

