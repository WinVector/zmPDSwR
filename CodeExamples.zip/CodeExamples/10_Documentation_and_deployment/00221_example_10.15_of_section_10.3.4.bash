# example 10.15 of section 10.3.4 
# (example 10.15 of section 10.3.4)  : Documentation and deployment : Using comments and version control for running documentation : Using version control to share work 
# Title: 
                                        git remote 


                                        git remote
                                        $ git remote --verbose
origin  git@github.com:WinVector/zmPDSwR.git (fetch)
origin  git@github.com:WinVector/zmPDSwR.git (push)

