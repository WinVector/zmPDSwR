# example 10.8 of section 10.3.1 
# (example 10.8 of section 10.3.1)  : Documentation and deployment : Using comments and version control for running documentation : Writing effective comments 
# Title: 
                                Useless comment 


                                Useless comment
                                #######################################
# Function: addone
# Author: John Mount
# Version: 1.3.11
# Location: RSource/helperFns/addone.R
# Date: 10/31/13
# Arguments: x
# Purpose: Adds one
#######################################
addone <- function(x) { x + 1 }

