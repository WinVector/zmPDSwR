# example:2_10.3.3 
# example:2 : Documentation and deployment : Using comments and version control for running documentation : Using version control to explore your project 
# Title: 
                                        Viewing detailed project history 


                                        Viewing detailed project history
                                        git log --graph --name-status
* commit c49c853cbcbb1e5a923d6e1127aa54ec7335d1b3
| Author: John Mount <jmount@win-vector.com>
| Date:   Sat Oct 26 09:22:02 2013 -0700
|
|     Add knitr and rendered result
|
| A     Buzz/.gitignore
| A     Buzz/buzz.Rnw
| A     Buzz/buzz.pdf
|
* commit 6ce20dd33c5705b6de7e7f9390f2150d8d212b42
| Author: John Mount <jmount@win-vector.com>
| Date:   Sat Oct 26 07:40:59 2013 -0700
|
|     update
|
| M     CodeExamples.zip

