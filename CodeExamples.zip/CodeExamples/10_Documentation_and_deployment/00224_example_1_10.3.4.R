# example:1_10.3.4 
# example:1 : Documentation and deployment : Using comments and version control for running documentation : Using version control to share work 
$ git remote --verbose
origin  git@github.com:WinVector/zmPDSwR.git (fetch)
origin  git@github.com:WinVector/zmPDSwR.git (push)
