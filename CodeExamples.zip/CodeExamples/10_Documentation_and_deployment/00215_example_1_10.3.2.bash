# example:1_10.3.2 
# example:1 : Documentation and deployment : Using comments and version control for running documentation : Using version control to record history 
# Title: 
                                        Saving your work in Git 


                                        Saving your work in Git
                                        git add -A . 	# Note: 1 
git commit 	# Note: 2 

# Note 1: 
#   Stage results to 
#   commit (specify what files should be 
#   committed) 

# Note 2: 
#   Actually perform 
#   the commit 

