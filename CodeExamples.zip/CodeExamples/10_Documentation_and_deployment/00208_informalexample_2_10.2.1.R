# informalexample:2_10.2.1 
# informalexample:2 : Documentation and deployment : Using knitr to produce milestone documentation : What is knitr? 
\documentclass{article} 	# Note: 1 
\begin{document} 	# Note: 2 
<<nameofblock>>= 	# Note: 3 
1+2 	# Note: 4 
@ 	# Note: 5 
\end{document} 	# Note: 6 

# Note 1: 
#   Latex declarations 
#   (not knitr) 

# Note 2: 
#   Latex declarations 
#   (not knitr) 

# Note 3: 
#   knit start chunk marker 

# Note 4: 
#   R code 

# Note 5: 
#   knit end chunk marker 

# Note 6: 
#   Latex declarations 
#   (not knitr) 
