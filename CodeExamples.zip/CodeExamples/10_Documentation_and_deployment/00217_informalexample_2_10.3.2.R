# informalexample:2_10.3.2 
# informalexample:2 : Documentation and deployment : Using comments and version control for running documentation : Using version control to record history 
$ git status
# On branch master
nothing to commit (working directory clean)
