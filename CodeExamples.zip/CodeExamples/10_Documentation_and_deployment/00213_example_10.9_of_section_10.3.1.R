# example 10.9 of section 10.3.1 
# (example 10.9 of section 10.3.1)  : Documentation and deployment : Using comments and version control for running documentation : Writing effective comments 
# Title: 
                                Worse than useless comment 


                                Worse than useless comment
                                # adds one
addtwo <- function(x) { x + 2 }

