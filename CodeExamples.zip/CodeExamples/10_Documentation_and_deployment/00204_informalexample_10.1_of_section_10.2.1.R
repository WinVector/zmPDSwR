# informalexample 10.1 of section 10.2.1 
# (informalexample 10.1 of section 10.2.1)  : Documentation and deployment : Using knitr to produce milestone documentation : What is knitr? 

library(knitr)
knit('simple.Rmd')

