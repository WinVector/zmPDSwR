# informalexample:2_8.1.3 
# informalexample:2 : Unsupervised methods : Cluster analysis : Hierarchical clustering with hclust 
# Title: Hierarchical clustering with hclust 

rect.hclust(pfit, k=5)

