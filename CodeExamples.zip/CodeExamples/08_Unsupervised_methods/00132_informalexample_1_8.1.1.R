# informalexample:1_8.1.1 
# informalexample:1 : Unsupervised methods : Cluster analysis : Distances 
# Title: Euclidean distance 

edist(x, y) <- sqrt((x[1]-y[1])^2 + (x[2]-y[2])^2 + ...)

