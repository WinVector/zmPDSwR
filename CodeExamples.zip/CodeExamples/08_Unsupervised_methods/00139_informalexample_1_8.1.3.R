# informalexample:1_8.1.3 
# informalexample:1 : Unsupervised methods : Cluster analysis : Hierarchical clustering with hclust 


                                rect.hclust(pfit, k=5)

