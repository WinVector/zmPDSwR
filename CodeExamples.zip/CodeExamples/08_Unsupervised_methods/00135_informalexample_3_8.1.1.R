# informalexample:3_8.1.1 
# informalexample:3 : Unsupervised methods : Cluster analysis : Distances 
mdist(x, y) <- sum(abs(x[1]-y[1]) + abs(x[2]-y[2]) + ...)
