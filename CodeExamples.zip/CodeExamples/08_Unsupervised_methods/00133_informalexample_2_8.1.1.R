# informalexample:2_8.1.1 
# informalexample:2 : Unsupervised methods : Cluster analysis : Distances 
# Title: Hamming distance 

hdist(x, y) <- sum((x[1] != y[1]) + (x[2] != y[2]) + ...)

