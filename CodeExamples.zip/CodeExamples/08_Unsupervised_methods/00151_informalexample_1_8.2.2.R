# informalexample:1_8.2.2 
# informalexample:1 : Unsupervised methods : Association rules : The example problem 
# Title: The example problem 

        "token" "userid"        "rating"        "title"
" a light in the storm" 55927   0       " A Light in the Storm"

