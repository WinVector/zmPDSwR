# informalexample:3_8.2.3 
# informalexample:3 : Unsupervised methods : Association rules : Mining association rules with the arules package 
> basketSizes <- size(bookbaskets)
> summary(basketSizes)
   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
    1.0     1.0     1.0    11.1     4.0 10250.0
