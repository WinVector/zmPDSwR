# informalexample:7_8.2.3 
# informalexample:7 : Unsupervised methods : Association rules : Mining association rules with the arules package 
# Title: A density plot of basket sizes 

> bookbaskets_use <- bookbaskets[basketSizes > 1]
> dim(bookbaskets_use)
[1]  40822 220447

