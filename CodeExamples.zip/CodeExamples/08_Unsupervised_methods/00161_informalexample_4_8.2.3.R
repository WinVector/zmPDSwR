# informalexample:4_8.2.3 
# informalexample:4 : Unsupervised methods : Association rules : Mining association rules with the arules package 
# Title: Scoring rules 

inspect(head((sort(rules, by="confidence")), n=5))

