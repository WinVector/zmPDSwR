# example:1_5.2.3 
# example:1 : Choosing and evaluating models : Evaluating models : Evaluating probability models 
# Title: Making a double density plot 

ggplot(data=spamTest) +
   geom_density(aes(x=pred,color=spam,linetype=spam))

