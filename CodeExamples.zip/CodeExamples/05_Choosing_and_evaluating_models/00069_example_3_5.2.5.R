# example:3_5.2.5 
# example:3 : Choosing and evaluating models : Evaluating models : Evaluating clustering models 
# Title: 
                                Calculating the size of each cluster 


                                Calculating the size of each cluster
                                > table(d$cluster)

 1  2  3  4  5
10 27 18 17 28

