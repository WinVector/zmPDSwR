# example 2.5 of section 2.1.2 
# (example 2.5 of section 2.1.2)  : Loading data into R : Working with data from files : Using R on less-structured data 
# Title: 
                                        Building a map to interpret loan use codes 


                                        Building a map to interpret loan use codes
                                        mapping <- list(
   'A40'='car (new)',
   'A41'='car (used)',
   'A42'='furniture/equipment',
   'A43'='radio/television',
   'A44'='domestic appliances',
   ...
  )

