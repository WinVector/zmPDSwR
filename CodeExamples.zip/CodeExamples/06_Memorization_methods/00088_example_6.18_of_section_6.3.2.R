# example 6.18 of section 6.3.2 
# (example 6.18 of section 6.3.2)  : Memorization methods : Building models using many variables : Using decision trees 
# Title: 
                                        Plotting the decision tree 


                                        Plotting the decision tree
                                        par(cex=0.7)
plot(tmodel)
text(tmodel)

