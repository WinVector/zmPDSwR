# informalexample:2_6.2.1 
# informalexample:2 : Memorization methods : Building single-variable models : Using categorical features 
> print(table218[,2]/(table218[,1]+table218[,2]))
      cJvF       UYBR       <NA>
0.05994389 0.08223821 0.26523297
