# informalexample:5_6.3.2 
# informalexample:5 : Memorization methods : Building models using many variables : Using decision trees 
par(cex=0.7)
plot(tmodel)
text(tmodel)
