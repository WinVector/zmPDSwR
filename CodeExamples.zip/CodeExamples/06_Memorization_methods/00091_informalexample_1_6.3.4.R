# informalexample:1_6.3.4 
# informalexample:1 : Memorization methods : Building models using many variables : Using Naive Bayes 
log(P(y==T|ev1...evN) ~ log(P(ev1|y==T) + ... + log(P(evN|y==T)
log(P(y==F|ev1...evN) ~ log(P(ev1|y==F) + ... + log(P(evN|y==F)
