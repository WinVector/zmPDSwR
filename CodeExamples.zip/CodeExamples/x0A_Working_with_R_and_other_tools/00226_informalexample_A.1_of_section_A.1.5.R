# informalexample A.1 of section A.1.5 
# (informalexample A.1 of section A.1.5)  : Working with R and other tools : Installing the tools : R resources 

install.packages('ctv',repos='https://cran.r-project.org')
library('ctv')
# install.views('TimeSeries') # can take a LONG time

