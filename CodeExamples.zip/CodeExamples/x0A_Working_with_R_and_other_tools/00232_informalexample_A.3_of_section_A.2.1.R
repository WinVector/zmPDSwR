# informalexample A.3 of section A.2.1 
# (informalexample A.3 of section A.2.1)  : Working with R and other tools : Starting with R : Primary features of R 

add <- function(a,b) { a + b}
add(1,2)
## [1] 3

