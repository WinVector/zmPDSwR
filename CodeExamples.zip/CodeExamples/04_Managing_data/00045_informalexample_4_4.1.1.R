# informalexample:4_4.1.1 
# informalexample:4 : Managing data : Cleaning data : Treating missing values (NAs) 
> summary(custdata$Income)

   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.    NA's
      0   25000   45000   66200   82000  615000     328
