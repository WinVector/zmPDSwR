# example:3_10.3.1 
# example:3 : Documentation and Deployment : Using comments and version control for running documentation : Writing effective comments 

# adds one
addtwo <- function(x) { x + 2 }

