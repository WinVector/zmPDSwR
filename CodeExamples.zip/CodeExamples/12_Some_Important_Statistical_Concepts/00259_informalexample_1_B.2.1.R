# informalexample:1_B.2.1 
# informalexample:1 : Some Important Statistical Concepts : Statistical theory : Statistical philosophy 
E[(y[i]-f(x[i,]))^2] = bias^2 + variance + irreducibleError
