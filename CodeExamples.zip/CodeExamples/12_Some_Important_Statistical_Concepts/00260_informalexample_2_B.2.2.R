# informalexample:2_B.2.2 
# informalexample:2 : Some Important Statistical Concepts : Statistical theory : A/B tests 
tab <- table(d)
print(tab)
     converted
group     0     1
    A 94979  5021
    B  9398   602
