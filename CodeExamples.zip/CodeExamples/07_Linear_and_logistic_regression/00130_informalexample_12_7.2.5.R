# informalexample:12_7.2.5 
# informalexample:12 : Linear and logistic regression : Using logistic regression : Reading the model summary and characterizing coefficients 
Warning message:
glm.fit: fitted probabilities numerically 0 or 1 occurred
