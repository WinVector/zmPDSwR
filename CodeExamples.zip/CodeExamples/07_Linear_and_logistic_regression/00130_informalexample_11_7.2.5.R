# informalexample:11_7.2.5 
# informalexample:11 : Linear and logistic regression : Using logistic regression : Reading the model summary and characterizing coefficients 
Number of Fisher Scoring iterations: 7
