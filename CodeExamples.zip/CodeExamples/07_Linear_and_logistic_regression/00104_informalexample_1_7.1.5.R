# informalexample:1_7.1.5 
# informalexample:1 : Linear and logistic regression : Using linear regression : Reading the model summary and characterizing coefficient
                                quality 
Call:
lm(formula = log(PINCP, base = 10) ~ AGEP + SEX + COW + SCHL,
    data = dtrain)
