# example:1_7.2.4 
# example:1 : Linear and logistic regression : Using logistic regression : Finding relations and extracting advice from logistic models 
# Title: 
                                The model coefficients 


                                The model coefficients
                                > coefficients(model)
             (Intercept)                     PWGT
             -4.41218940               0.00376166
                 UPREVIS              CIG_RECTRUE
             -0.06328943               0.31316930
      GESTREC3< 37 weeks DPLURALtriplet or higher
              1.54518311               1.39419294
             DPLURALtwin             ULD_MECOTRUE
              0.31231871               0.81842627
          ULD_PRECIPTRUE           ULD_BREECHTRUE
              0.19172008               0.74923672
            URF_DIABTRUE           URF_CHYPERTRUE
             -0.34646672               0.56002503
          URF_PHYPERTRUE            URF_ECLAMTRUE
              0.16159872               0.49806435

