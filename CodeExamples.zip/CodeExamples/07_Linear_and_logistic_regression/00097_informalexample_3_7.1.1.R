# informalexample:3_7.1.1 
# informalexample:3 : Linear and logistic regression : Using linear regression : Understanding linear regression 
y[i] = b[1] x[i,1] + b[2] x[i,2] + ... b[n] x[i,n] + e[i]
