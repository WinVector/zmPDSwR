# informalexample:4_7.1.1 
# informalexample:4 : Linear and logistic regression : Using linear regression : Understanding linear regression 
x[i]^2  nearly equals b[0] + b[1] x[i]
