# informalexample:2_7.2.5 
# informalexample:2 : Linear and logistic regression : Using logistic regression : Reading the model summary and characterizing coefficients 
Call:
glm(formula = fmla, family = binomial(link = "logit"), data = train)
