# informalexample:5_7.1.5 
# informalexample:5 : Linear and logistic regression : Using linear regression : Reading the model summary and characterizing coefficient
                                quality 
# Title: Overall model quality summaries 

modelResidualError <- sqrt(sum(residuals(model)^2)/df)

