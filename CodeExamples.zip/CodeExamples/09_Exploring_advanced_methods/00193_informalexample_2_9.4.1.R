# informalexample:2_9.4.1 
# informalexample:2 : Exploring advanced methods : Using support vector machines to model complicated decision
            boundaries : Understanding support vector machines 
w %*% phi(x) + b >= u
