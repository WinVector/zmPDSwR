# informalexample:1_9.1.1 
# informalexample:1 : Exploring advanced methods : Using bagging and random forests to reduce training variance : Using bagging to improve prediction 
         model  accuracy        f1  dev.norm
tree, training 0.9104514 0.7809002 0.5618654

         model  accuracy        f1  dev.norm
    tree, test 0.8799127 0.7091151 0.6702857
