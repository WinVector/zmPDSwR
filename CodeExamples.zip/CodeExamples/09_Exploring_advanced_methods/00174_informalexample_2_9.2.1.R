# informalexample:2_9.2.1 
# informalexample:2 : Exploring advanced methods : Using generalized additive models (GAMs) to learn non-monotone
            relationships : Understanding GAMs 
f(x[i,]) = a0 + s_1(x[i,1]) + s_2(x[i,2]) + ... s_n(x[i,n])
