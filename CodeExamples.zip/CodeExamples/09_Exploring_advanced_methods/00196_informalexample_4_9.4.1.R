# informalexample:4_9.4.1 
# informalexample:4 : Exploring advanced methods : Using support vector machines to model complicated decision
            boundaries : Understanding support vector machines 
w =sum(a1*phi(s1),...,am*phi(sm))
