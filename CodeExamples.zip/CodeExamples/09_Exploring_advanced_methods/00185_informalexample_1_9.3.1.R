# informalexample:1_9.3.1 
# informalexample:1 : Exploring advanced methods : Using kernel methods to increase data separation : Understanding kernel functions 
k(u,v) = phi(u) %*% phi(v)
