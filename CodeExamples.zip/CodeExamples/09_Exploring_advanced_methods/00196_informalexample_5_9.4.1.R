# informalexample:5_9.4.1 
# informalexample:5 : Exploring advanced methods : Using support vector machines to model complicated decision
            boundaries : Understanding support vector machines 
w %*% phi(x) + b = sum(a1*k(s1,x),...,am*k(sm,x)) + b
