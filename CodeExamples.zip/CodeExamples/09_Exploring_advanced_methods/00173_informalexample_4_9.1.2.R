# informalexample:4_9.1.2 
# informalexample:4 : Exploring advanced methods : Using bagging and random forests to reduce training variance : Using random forests to further improve prediction 
               model  accuracy        f1  dev.norm
Random Forest, train 0.9925175 0.9810408 0.1159385
     RF small, train 0.9934830 0.9834694 0.1198645

 Random Forest, test 0.9628821 0.9063584 0.3020674
      RF small, test 0.9606987 0.9015467 0.2932659
