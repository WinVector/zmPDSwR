# example:3_9.4.3 
# example:3 : Exploring advanced methods : Using SVMs to model complicated decision boundaries : Using SVMs on real data 
# Title: Printing the SVM results
                    summary 

Printing the SVM results
                    summaryprint(svmM)
Support Vector Machine object of class "ksvm" 

SV type: C-svc  (classification) 
 parameter : cost C = 10 

Gaussian Radial Basis kernel function. 
 Hyperparameter : sigma =  0.0299836801848002 

Number of Support Vectors : 1118 

Objective Function Value : -4642.236 
Training error : 0.028482 
Cross validation error : 0.076998 
Probability model included.

