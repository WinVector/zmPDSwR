# informalexample:6_9.4.1 
# informalexample:6 : Exploring advanced methods : Using support vector machines to model complicated decision
            boundaries : Understanding support vector machines 
w ~ sum(a1*p(s1),...,am*p(sm))
