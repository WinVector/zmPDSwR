# informalexample:3_9.4.1 
# informalexample:3 : Exploring advanced methods : Using support vector machines to model complicated decision
            boundaries : Understanding support vector machines 
w %*% phi(x) + b <= v
