# example 2.14 of section 2.2.3 
# (example 2.14 of section 2.2.3)  : Loading data into R : Working with relational databases : Working with the PUMS data 
# Title: Summarizing the classifications of work 

summary(dtrain$COW)
## Employee of a private for-profit      Federal government employee
##                              423                               21
##        Local government employee  Private not-for-profit employee
##                               39                               55
##       Self-employed incorporated   Self-employed not incorporated
##                               17                               16
##        State government employee
##                               24

