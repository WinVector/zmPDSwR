# example 2.7 of section 2.1.2 
# (example 2.7 of section 2.1.2)  : Loading data into R : Working with data from files : Using R on less-structured data 
# Title: Summary of Good.Loan and Purpose 

> table(d$Purpose,d$Good.Loan) 
                     
                      BadLoan GoodLoan
  business                 34       63
  car (new)                89      145
  car (used)               17       86
  domestic appliances       4        8
  education                22       28
  furniture/equipment      58      123
  others                    5        7
  radio/television         62      218
  repairs                   8       14
  retraining                1        8

