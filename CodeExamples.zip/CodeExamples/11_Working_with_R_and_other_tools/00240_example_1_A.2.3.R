# example:1_A.2.3 
# example:1 : Working with R and other tools : Starting with R : Loading data from https sources 
# Title: 
                                Loading UCI car data directly from GitHub using https 


                                Loading UCI car data directly from GitHub using https
require(RCurl) 	# Note: 1 
urlBase <- 
  'https://raw.github.com/WinVector/zmPDSwR/master/' 	# Note: 2 
mkCon <- function(nm) { 	# Note: 3 
   textConnection(getURL(paste(urlBase,nm,sep='')))
}
cars <- read.table(mkCon('UCICar/car.data.csv'), 	# Note: 4 
    sep=',',header=T,comment.char='')

# Note 1: 
#   Bring in the RCurl library for more connection methods 

# Note 2: 
#   Form a valid https base URL for raw access to the GitHub repository 

# Note 3: 
#   Define a function that wraps a URL path fragment into a usable https connection 

# Note 4: 
#   Load the car data from GitHub over https 

