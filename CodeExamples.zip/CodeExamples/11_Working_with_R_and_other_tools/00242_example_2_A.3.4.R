# example:2_A.3.4 
# example:2 : Working with R and other tools : Using databases with R : An example SQL data transformation task 
# Title: 
                                        The hotel reservation and price data 


                                        The hotel reservation and price data
                                        > print(bookings)
        date day.of.stay X1.before X2.before X3.before
1 2009-06-30         105        98        95        96
2 2009-07-01         103       100        98        95
3 2009-07-02         105        95        90        80
4 2009-07-03         105       105       107        98
> print(prices)
        date day.of.stay X1.before X2.before X3.before
1 2009-06-30         250       200       280       300
2 2009-07-01         200       250       290       250
3 2009-07-02         200       200       250       275
4 2009-07-03         250       300       300       200

