# informalexample:5_A.2.1 
# informalexample:5 : Working with R and other tools : Starting with R : Primary Features of R 

> add <- function(a,b) { a + b}
> add(1,2)
[1] 3

