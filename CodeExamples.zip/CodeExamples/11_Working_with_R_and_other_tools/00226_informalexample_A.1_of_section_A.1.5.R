# informalexample A.1 of section A.1.5 
# (informalexample A.1 of section A.1.5)  : Working with R and other tools : Installing the tools : R resources 


install.packages('ctv')
library('ctv')
install.views('TimeSeries')

