# informalexample:2_A.2.1 
# informalexample:2 : Working with R and other tools : Starting with R : Primary Features of R 

> divide <- function(numerator,denominator) { numerator/denominator }
> divide(1,2)
[1] 0.5
> divide(2,1)
[1] 2
> divide(denominator=2,numerator=1)
[1] 0.5

