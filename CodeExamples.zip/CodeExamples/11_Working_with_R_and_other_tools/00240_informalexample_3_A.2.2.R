# informalexample:3_A.2.2 
# informalexample:3 : Working with R and other tools : Starting with R : Primary R data types 

> factor('red',levels=c('red','orange'))
[1] red
Levels: red orange
> factor('apple',levels=c('red','orange'))
[1] <NA>
Levels: red orange

