# informalexample:3_A.2.1 
# informalexample:3 : Working with R and other tools : Starting with R : Primary features of R 
# Title: R is a generic language 

> add(1,'fred')
Error in a + b : non-numeric argument to binary operator

