# informalexample:1_A.2.2 
# informalexample:1 : Working with R and other tools : Starting with R : Primary R data types 
# Title: Numbers in R 

> vec <- c(2,3)
> vec[[2]] <- 5
> print(vec)
[1] 2 5

