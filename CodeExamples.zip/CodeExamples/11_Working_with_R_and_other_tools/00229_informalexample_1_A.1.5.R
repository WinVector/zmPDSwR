# informalexample:1_A.1.5 
# informalexample:1 : Working with R and other tools : Installing the tools : R resources 
install.packages('ctv')
library('ctv')
install.views('TimeSeries')
