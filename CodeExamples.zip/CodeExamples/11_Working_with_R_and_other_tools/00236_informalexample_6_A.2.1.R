# informalexample:6_A.2.1 
# informalexample:6 : Working with R and other tools : Starting with R : Primary Features of R 

> add(1,'fred')
Error in a + b : non-numeric argument to binary operator

