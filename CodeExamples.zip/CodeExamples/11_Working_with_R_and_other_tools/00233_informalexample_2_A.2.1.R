# informalexample:2_A.2.1 
# informalexample:2 : Working with R and other tools : Starting with R : Primary features of R 
# Title: R is a functional language 

> add <- function(a,b) { a + b}
> add(1,2)
[1] 3

