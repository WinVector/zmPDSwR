# informalexample:2_A.2.1 
# informalexample:2 : Working with R and other tools : Starting with R : Primary features of R 


                                        > add <- function(a,b) { a + b}
> add(1,2)
[1] 3

