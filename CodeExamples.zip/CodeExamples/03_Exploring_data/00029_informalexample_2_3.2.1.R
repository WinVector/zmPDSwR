# informalexample:2_3.2.1 
# informalexample:2 : Exploring data : Spotting problems using graphics and visualization : Visually checking distributions for a single variable 


                    ggplot(custdata) + geom_bar(aes(x=marital.stat), fill="gray")

